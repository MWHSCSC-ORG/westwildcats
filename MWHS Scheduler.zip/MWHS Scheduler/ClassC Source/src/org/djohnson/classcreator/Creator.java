package org.djohnson.classcreator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Creator {

	private ArrayList<String> classesToExport;

	public static void main(String[] args) {
		new Creator();
	}

	public Creator() {
		classesToExport = new ArrayList<String>();
		String input = "";
		Scanner sc = new Scanner(System.in);
		System.out
				.println("Entert the course data, if multiple pre-reqs, seperate with a dash (-) e.g 0000-0522");
		while (!input.equalsIgnoreCase("exit")) {
			String toFinal = "";
			System.out.print("Course Number:\t");
			input = sc.nextLine();
			toFinal += input;
			if(input.contains("exit")){
				break;
			}
			System.out.print("\nCourse Name:\t");
			input = "," + sc.nextLine();
			toFinal += input;
			if(input.contains("exit")){
				break;
			}
			System.out.print("\nCourse Credits:\t");
			input = "," + sc.nextLine();
			toFinal += input;
			if(input.contains("exit")){
				break;
			}
			System.out.print("\nMinimum grade:\t");
			input = "," + sc.nextLine();
			toFinal += input;
			if(input.contains("exit")){
				break;
			}
			System.out.print("\nPre-req number(s)\t");
			input = "," + sc.nextLine();
			toFinal += input;
			if(input.contains("exit")){
				break;
			}
			System.out.print("\nClass Type\t");
			input = "," + sc.nextLine();
			toFinal += input;
			if(input.contains("exit")){
				break;
			}
			System.out.println("ADDED: \t" + toFinal);
			classesToExport.add(toFinal);
			System.out.println("\n");
		}
		try {
			File file = new File("exported.txt");

			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			String content1 = "";
			for (String content : classesToExport) {
				content1 += content + "\n";
			}
			bw.write(content1);
			bw.close();

			System.out.println("Done, wrote to exported.txt");
		} catch (Exception e) {

		}

	}
}
