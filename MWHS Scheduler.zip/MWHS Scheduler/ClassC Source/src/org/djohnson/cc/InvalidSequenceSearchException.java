package org.djohnson.cc;

public class InvalidSequenceSearchException extends Exception{

	private static final long serialVersionUID = 933489919063071614L;
	
	@Override
	public void printStackTrace() {
		System.err.println("Class is not contained in a sequence.");
		super.printStackTrace();
	}
	
}
