package org.djohnson.cc;

import java.io.Serializable;

/**
 * 
 * @author Declan Johnson
 * 
 */
public class CCClass implements Serializable{

	private static final long serialVersionUID = 1183649899350025191L;
	private String courseNumber;
	private int creditNumber;
	private String courseName;
	private String courseDescription;
	private int minGrade;
	private String[] preReqs;
	private String type;

	public CCClass(String courseNumber, String courseName, int creditNumber, int minGrade, String[] preReqs, String type) {
		this.courseNumber = courseNumber;
		this.courseName = courseName;
		this.creditNumber = creditNumber;
		this.minGrade = minGrade;
		this.preReqs = preReqs;
		this.type = type;	
	}

	public CCClass(String courseNumber, String courseName, int creditNumber, String courseDescription) {
		this.courseNumber = courseNumber;
		this.courseName = courseName;
		this.courseDescription = courseDescription;
		this.creditNumber = creditNumber;
	}
	
	public String getCourseNumber() {
		return courseNumber;
	}

	public void setCourseNumber(String courseNumber) {
		this.courseNumber = courseNumber;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseDescription() {
		return courseDescription;
	}

	public void setCourseDescription(String courseDescription) {
		this.courseDescription = courseDescription;
	}

	public int getCreditNumber() {
		return creditNumber;
	}

	public void setCreditNumber(int creditNumber) {
		this.creditNumber = creditNumber;
	}

	public int getMinGrade() {
		return minGrade;
	}

	public void setMinGrade(int minGrade) {
		this.minGrade = minGrade;
	}

	public String[] getPreReqs() {
		return preReqs;
	}

	public void setPreReqs(String[] preReqs) {
		this.preReqs = preReqs;
	}

	public String getType() {
		return type;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return courseNumber + " | " + courseName + " | " + creditNumber;
	}
	
}
