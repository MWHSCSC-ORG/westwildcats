package org.djohnson.cc;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Data manager for the CC application. Reads the data from outside files and
 * adds it to the application.
 * 
 * @author Declan Johnson
 * 
 */
public class CCDataManager {

	private File f;

	public CCDataManager(String filePath) {
		f = new File(filePath);
	}

	public CCDataManager() {

	}

	/**
	 * Reads the file and returns the read object, null otherwise.
	 * 
	 * @return Object read from the file
	 */
	public Object getData() {
		try {

			FileInputStream fis = new FileInputStream(f);
			ObjectInputStream ois = new ObjectInputStream(fis);
			return ois.readObject();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Writes the provided object to the file. Must be <code>Serializable</code>
	 * .
	 * 
	 * @param o
	 *            Object to be written
	 * @return True if successful, false otherwise.
	 */
	public boolean writeData(Object object) {
		try {
			FileOutputStream fos = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(object);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Reads the file with the class data and puts it in an array list.
	 * 
	 * @param filePath
	 *            Path of the file to read
	 * @return <code>ArrayList<CCClass></code> of Classes
	 */
	public ArrayList<CCClass> getClassData(String filePath) {
		try {
			boolean start = false;
			BufferedReader br = new BufferedReader(new FileReader(new File(
					filePath)));
			ArrayList<CCClass> classes = new ArrayList<CCClass>();

			String line;
			while ((line = br.readLine()) != null) {
				if(start){
					if(line.equals("*stop CLASS_LIST")){
						break;
					}
					String[] content = line.replaceAll("\t", "").split(",");
					try{
						classes.add(new CCClass(content[0], content[1], Integer.parseInt(content[2]), Integer.parseInt(content[3]), content[4].split("-"), content[5]));
					} catch (Exception e){
						System.err.println("Invalid line: " + line);
					}
				}else{
					if(line.equals("*start CLASS_LIST")){
						start = true;
					}
				}
			}
			br.close();
			return classes;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;

	}
	
	public Map<String, String> getTranslations(String filePath){
		Map<String, String> hashMap = new HashMap<String, String>();
		boolean read = false;
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(filePath)));
			String line = "";
			while((line = br.readLine()) != null){
				
				if(read){
					if(line.equals("*stop TYPE_TRANSLAT")){
						break;
					}
					String[] split = line.replaceAll("\t", "").split("=>");
					if(!hashMap.containsKey(split[0])){
						hashMap.put(split[0], split[1]);
					}
				}else{
					if(line.equals("*start TYPE_TRANSLAT")){
						read = true;
					}
				}
			}
			
			br.close();
			return hashMap;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList<CCClassSequence> getClassSequences(String filePath, CCScheduler sched){
		boolean read = false;
		ArrayList<CCClassSequence> seqs = new ArrayList<CCClassSequence>();
		try{
			BufferedReader br = new BufferedReader(new FileReader(new File(filePath)));
			String line;
			while((line = br.readLine()) != null){
				if(read){
					if(line.equals("*stop CLASS_SEQS")){
						break;
					}
					line = line.replaceAll("\t", "");
					String[] strs = line.split(">>");
					ArrayList<CCClass> classes = new ArrayList<CCClass>();
					for(String s : strs){
						classes.add(sched.findClassById(s));
					}
					seqs.add(new CCClassSequence(sched, classes));
				}else{
					if(line.equals("*start CLASS_SEQS")){
						read = true;
					}
				}
			}
			br.close();
			return seqs;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean writeSession(CCSession session, String path) {

		File fi;
		try {
			fi = new File(path + ".ser");
			fi.createNewFile();
			FileOutputStream fos = new FileOutputStream(fi);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(session);
			oos.close();
			fos.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return false;
	}

	public CCSession readSession(File f) {
		
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
			ObjectInputStream ois = new ObjectInputStream(fis);
			return (CCSession) ois.readObject();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
