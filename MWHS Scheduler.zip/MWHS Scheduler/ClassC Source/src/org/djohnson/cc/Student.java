package org.djohnson.cc;

import java.io.Serializable;

import javax.swing.JOptionPane;

public class Student implements Serializable{
	
	private static final long serialVersionUID = -1616469880515558341L;
	private String name;
	private String advisor;
	private String idNumber;
	private String grade;
	
	public Student(String name, String advisor, String idNumber, String grade){
		this.name = name.trim();
		this.advisor = advisor.trim();
		this.idNumber = idNumber.trim();
		this.setGrade(grade);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdvisor() {
		return advisor;
	}

	public void setAdvisor(String advisor) {
		this.advisor = advisor;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getAccName() {
		String total = "";
		String[] splitName = name.split(" ");
		try{
			total += splitName[0].toLowerCase().charAt(0);
			total += splitName[1].toLowerCase();
			total += idNumber.substring(idNumber.length()-3);
		}catch(Exception e){
			name = JOptionPane.showInputDialog("First and Last name: (e.x Declan Johnson)");
			getAccName();
		}
		
		return total;
	}
	
}
