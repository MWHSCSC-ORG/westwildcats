package org.djohnson.cc;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Map;

public class CCDialog extends JDialog {

	private static final long serialVersionUID = 6630273154217145157L;
	private JTextField search;
	private JButton buttonCancel, buttonOk;
	private Container cp;
	private String searchTerm;
	private JComboBox<Object> classes;
	private ArrayList<CCClass> allClasses;
	private JRadioButton fiveOnlyRadio;
	private JRadioButton tenOnlyRadio;
	private JRadioButton allClassRadio;
	private CCClass selectedClass;
	private Map<String, String> translations;
	private boolean searchByclassType;

	public CCDialog(JFrame fr, ArrayList<CCClass> allClasses, Map<String, String> translations, boolean searchByclassType) {
		super(fr, "Add a class...", true);
		cp = getContentPane();
		this.translations = translations;
		searchTerm = "";
		this.searchByclassType = searchByclassType;
		this.allClasses = allClasses;
		search = new JTextField(25);
		classes = new JComboBox<Object>(allClasses.toArray());
		classes.setPrototypeDisplayValue("WWWWWWWWWWWWWWWWWWWWWWWWW");
		classes.setMinimumSize(new Dimension(search.getWidth(), search.getHeight()));

		buttonCancel = new JButton("Cancel");
		buttonOk = new JButton("Accept");
		
		buttonCancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				selectedClass = null;
			}
		});
		
		buttonOk.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				selectedClass = (CCClass) classes.getSelectedItem();
				setVisible(false);
			}
		});
		
		search.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent arg0) {
				searchTerm = search.getText();
				updateSearch();
			}

			@Override
			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}
		});

		fiveOnlyRadio = new JRadioButton("5 credits only");
		tenOnlyRadio = new JRadioButton("10 credits only");
		allClassRadio = new JRadioButton("All classes", true);
		
		fiveOnlyRadio.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent arg0) {
				updateSearch();
			}
		});
		tenOnlyRadio.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent arg0) {
				updateSearch();
			}
		});
		allClassRadio.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent arg0) {
				updateSearch();
			}
		});
		
		ButtonGroup group = new ButtonGroup();
		group.add(fiveOnlyRadio);
		group.add(tenOnlyRadio);
		group.add(allClassRadio);
		
		setSize(350, 215);
		cp.setLayout(new FlowLayout());
		if(!searchByclassType){
			cp.add(new JLabel("Search: "));
		}else{
			cp.add(new JLabel("Subject Search: "));
		}
		cp.add(search);
		cp.add(classes);
		cp.add(allClassRadio);
		cp.add(fiveOnlyRadio);
		cp.add(tenOnlyRadio);
		cp.add(buttonOk);
		cp.add(buttonCancel);
		addWindowListener(new WA());
		
		super.setSize(new Dimension(325, 170));
		super.setLocation(fr.getX() + ((fr.getWidth()/2) - (getWidth()/2)), fr.getY() + ((fr.getHeight()/2) - (getHeight()/2)));
		setResizable(false);
	}

	protected void updateSearch() {
		ArrayList<CCClass> searchedClasses = new ArrayList<CCClass>();
		for (CCClass c : allClasses) {
			if(!searchByclassType){
				if (allClassRadio.isSelected()) {
					if (c.getCourseName().toLowerCase().contains(searchTerm.toLowerCase())) {
						searchedClasses.add(c);
					}
				}else if(fiveOnlyRadio.isSelected()){
					if (c.getCourseName().toLowerCase().contains(searchTerm.toLowerCase()) && c.getCreditNumber() == 5) {
						searchedClasses.add(c);
					}
				}else if(tenOnlyRadio.isSelected()){
					if (c.getCourseName().toLowerCase().contains(searchTerm.toLowerCase()) && c.getCreditNumber() == 10) {
						searchedClasses.add(c);
					}
				}
			}else{
				if(allClassRadio.isSelected()){
					if(translations.get(c.getType()).toLowerCase().contains(searchTerm.toLowerCase())){
						searchedClasses.add(c);
					}
				}
				else if(fiveOnlyRadio.isSelected()){
					if(translations.get(c.getType()).toLowerCase().contains(searchTerm.toLowerCase()) && c.getCreditNumber() == 5){
						searchedClasses.add(c);
					}
				}else if(tenOnlyRadio.isSelected()){
					if(translations.get(c.getType()).toLowerCase().contains(searchTerm.toLowerCase()) && c.getCreditNumber() == 10){
						searchedClasses.add(c);
					}
				}
			}
		}
		classes.removeAllItems();
		for (CCClass c : searchedClasses) {
			classes.addItem(c);
		}
		
	}

	public String getSearch() {
		return search.getText();
	}
	
	class WA extends WindowAdapter {
		public void windowClosing(WindowEvent ev) {
			setVisible(false);
		}
	}

	public Object getSelectedClass() {
		return selectedClass;
	}
}
