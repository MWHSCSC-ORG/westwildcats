package org.djohnson.cc;

import java.io.Serializable;
import java.util.ArrayList;

public class CCSession implements Serializable{
	
	private static final long serialVersionUID = 4242974189339251097L;
	private ArrayList<CCClass> selectedClasses;
	private Student currStudent;
	
	public CCSession(ArrayList<CCClass> selectedClasses, Student currStudent){
		this.selectedClasses = selectedClasses;
		this.currStudent = currStudent;
	}

	public ArrayList<CCClass> getSelectedClasses() {
		return selectedClasses;
	}

	public void setSelectedClasses(ArrayList<CCClass> selectedClasses) {
		this.selectedClasses = selectedClasses;
	}

	public Student getCurrStudent() {
		return currStudent;
	}

	public void setCurrStudent(Student currStudent) {
		this.currStudent = currStudent;
	}
	
	
	
}
