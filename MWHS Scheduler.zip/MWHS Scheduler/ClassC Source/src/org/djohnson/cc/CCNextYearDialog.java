package org.djohnson.cc;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class CCNextYearDialog extends JDialog{

	private static final long serialVersionUID = 3316273769604006618L;
	private JTable table;
	private DefaultTableModel tableModel;
	private ArrayList<CCClass> allNewClasses;
	private ArrayList<CCClass> bufferArray;
	
	public CCNextYearDialog(JFrame frame, ArrayList<CCClass> classesToCheck, ArrayList<CCClass> allClasses, CCDataManager manager, String dataPath){
		super(frame, "Classes for next year", true);
		this.setLayout(new FlowLayout());
		allNewClasses = new ArrayList<CCClass>();
		CCScheduler sched = new CCScheduler(allClasses);
		sched.setClassSeqs(manager.getClassSequences(dataPath, sched));
		this.setResizable(false);
		this.setSize(new Dimension(470, 500));
		for(CCClass c : classesToCheck){
			try{
				if(sched.getNextInSequence(c) != null){
					allNewClasses.add(sched.getNextInSequence(c));
				}
			}catch(Exception e){
			}
		}
		
		table = new JTable();
		tableModel = new DefaultTableModel() {

			private static final long serialVersionUID = 5928716993276473236L;

			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table.setModel(tableModel);
		tableModel.addColumn("Class #");
		tableModel.addColumn("Class name");
		tableModel.addColumn("Credit number");
		table.getColumnModel().getColumn(0).setMaxWidth(50);
		table.getColumnModel().getColumn(0).setMinWidth(50);
		table.setAutoCreateRowSorter(true);

		JScrollPane scrollPane = new JScrollPane(table);
		this.add(scrollPane);
		
		JButton okButton = new JButton("Accept");
		okButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				bufferArray = allNewClasses;
				setVisible(false);
			}
		});
		this.add(okButton);
		
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				allNewClasses = null;
				setVisible(false);
			}
		});
		this.add(cancelButton);
		
		for(CCClass c : allNewClasses){
			tableModel.addRow(new Object[] { c.getCourseNumber(), c.getCourseName(), c.getCreditNumber() });
		}
		super.setLocation(frame.getX() + ((frame.getWidth()/2) - (getWidth()/2)), frame.getY() + ((frame.getHeight()/2) - (getHeight()/2)));
		addWindowListener(new WA());
	}
	
	public ArrayList<CCClass> getNewClasses(){
		return bufferArray;
	}
	
	class WA extends WindowAdapter {
		public void windowClosing(WindowEvent ev) {
			setVisible(false);
		}
	}
	
}
