package org.djohnson.cc;

import java.io.*;
import java.util.*;

public class CCClassSequence implements Serializable {

	private static final long serialVersionUID = 6630107089901345561L;
	private ArrayList<CCClass> progression;
	private CCScheduler sched;

	public CCClassSequence(CCScheduler sched, ArrayList<CCClass> progression) {
		this.sched = sched;
		this.progression = progression;
	}

	public CCClassSequence(CCScheduler sched, String... progression) {
		this.sched = sched;
		ArrayList<CCClass> classes = new ArrayList<CCClass>();
		for (String s : progression) {
			CCClass c = this.sched.findClassById(s);
			if (c != null) {
				classes.add(c);
			}
		}
		this.progression = classes;
	}
	
	public boolean sequenceContainsClass(CCClass c){
		for(CCClass class1 : progression){
			if(class1.getCourseNumber().equals(c.getCourseNumber())){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Gets next class in sequence, returns null if its the last class in the sequence. 
	 * Throws InvalidSequenceSearchException if no class sequence is found.
	 * 
	 * @param c Class to search for
	 * @return Next class in sequence or null for last class
	 * @throws InvalidSequenceSearchException
	 */
	public CCClass getNextInSequence(CCClass c) throws InvalidSequenceSearchException {
		for (int i = 0; i < progression.size(); i++) {
			if (progression.get(i).getCourseNumber().equals(c.getCourseNumber())) {
				if (i == progression.size() - 1) {
					return null;
				} else {
					return progression.get(i + 1);
				}
			}
		}
		throw new InvalidSequenceSearchException();
	}

}
