package org.djohnson.cc;

import java.awt.EventQueue;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import net.miginfocom.swing.MigLayout;

import javax.swing.JMenu;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.awt.print.PrinterJob;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import org.djohnson.printing.CCClassList;

public class CCWindow {

	private static final String DATA_PATH = "classdata/data.txt";

	private JFrame frame;
	private JTable table;
	private DefaultTableModel tableModel;
	private JLabel totalCredits;
	private JLabel lblStudent;
	private JFileChooser fc;

	private ArrayList<CCClass> allClasses;
	private ArrayList<CCClass> selectedClasses;
	private Map<String, String> translations;
	private Student currStudent;
	private CCSession initSession;

	private String name = null;
	private String idNumber = null;
	private String advisor = null;
	private String grades = null;

	private boolean hasSaved;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CCWindow window = new CCWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CCWindow() {
		CCDataManager dataMan = new CCDataManager();
		allClasses = dataMan.getClassData(DATA_PATH);
		translations = dataMan.getTranslations(DATA_PATH);

		selectedClasses = new ArrayList<CCClass>();
		hasSaved = true;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();

		try {
			InputStream imgStream = CCWindow.class
					.getResourceAsStream("res/icon.png");
			BufferedImage io = ImageIO.read(imgStream);
			frame.setIconImage(io);
			imgStream.close();

		} catch (IOException e1) {
			e1.printStackTrace();
		}

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}

		fc = new JFileChooser();

		Object[] options = { "Load...", "New...", "Cancel" };
		int res = JOptionPane.showOptionDialog(frame,
				"Load a session or create new?", "Load session",
				JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,
				null, options, options[2]);
		if (res == 2) {
			System.exit(0);
		} else if (res == 1) {
			getStudentInfo();
			currStudent = new Student(name, advisor, idNumber,
					grades.toLowerCase());
		} else if (res == 0) {
			setStartingSession();
		}

		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);

		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);

		JMenuItem mntmExport = new JMenuItem("Export");
		mntmExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				exportSession();
			}
		});
		mnFile.add(mntmExport);

		JMenuItem mntmImport = new JMenuItem("Import");
		mntmImport.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				importSession();
			}
		});
		mnFile.add(mntmImport);
		mnFile.addSeparator();

		JMenuItem mntmRereadClasses = new JMenuItem("Re-read classes");
		mntmRereadClasses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				allClasses = new CCDataManager()
						.getClassData("classdata/data.txt");
				JOptionPane.showMessageDialog(frame,
						"Class data has been read.");
			}
		});
		mnFile.add(mntmRereadClasses);
		mnFile.addSeparator();

		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// EXIT
				System.exit(0);
			}
		});
		mnFile.add(mntmExit);

		JMenu mnClasses = new JMenu("Classes");
		menuBar.add(mnClasses);

		JMenuItem mntmAddAClass = new JMenuItem("Add a class");
		mntmAddAClass.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addElement(false);
			}
		});
		mntmAddAClass.setMnemonic(KeyEvent.VK_MINUS);
		mnClasses.add(mntmAddAClass);

		JMenuItem mntmAddAClassByType = new JMenuItem("Add a class by subject");
		mntmAddAClassByType.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addElement(true);
			}
		});
		mntmAddAClassByType.setMnemonic(KeyEvent.VK_MINUS);
		mnClasses.add(mntmAddAClassByType);

		JMenuItem mntmRemoveSelectedClass = new JMenuItem(
				"Remove Selected Class");
		mntmRemoveSelectedClass.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removeElement();
			}
		});
		mntmRemoveSelectedClass.setMnemonic(KeyEvent.VK_PLUS);
		mnClasses.add(mntmRemoveSelectedClass);

		JMenuItem mntmAdvanceClasses = new JMenuItem(
				"Create Schedule for next year");
		mntmAdvanceClasses.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				createNextYearDialog();
			}
		});
		mnClasses.add(mntmAdvanceClasses);

		JMenu mnPrint = new JMenu("Print");
		menuBar.add(mnPrint);

		JMenuItem mntmPrint = new JMenuItem("Print...");
		mntmPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PrinterJob job = PrinterJob.getPrinterJob();
				job.setPrintable(new CCClassList(selectedClasses, currStudent));
				boolean doPrint = job.printDialog();
				if (doPrint) {
					try {
						job.print();
					} catch (Exception e) {
						System.err.println("Error printing");
					}
				}
			}
		});
		mnPrint.add(mntmPrint);

		JMenu mnUser = new JMenu("User");
		menuBar.add(mnUser);

		JMenuItem mntmChangeUser = new JMenuItem("Change User");
		mntmChangeUser.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				changeUser();
			}
		});
		mnUser.add(mntmChangeUser);
		
		JMenu mnAbout = new JMenu("About");
		menuBar.add(mnAbout);
		JMenuItem mntmAbout = new JMenuItem("About");
		mntmAbout.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(frame, "Created by: Declan Johnson", "About", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		mnAbout.add(mntmAbout);

		frame.getContentPane().setLayout(
				new MigLayout("", "[grow]", "[:46.00:30.00,grow][grow]"));

		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, "flowx,cell 0 0,alignx left,growy");

		totalCredits = new JLabel("Total credits: 0");
		panel.add(totalCredits);

		table = new JTable();
		tableModel = new DefaultTableModel() {

			private static final long serialVersionUID = 5928716993276473236L;

			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table.setModel(tableModel);
		tableModel.addColumn("Class #");
		tableModel.addColumn("Class name");
		tableModel.addColumn("Credit number");
		table.getColumnModel().getColumn(0).setMaxWidth(50);
		table.getColumnModel().getColumn(0).setMinWidth(50);
		table.setAutoCreateRowSorter(true);

		JScrollPane scrollPane = new JScrollPane(table);

		frame.getContentPane().add(scrollPane, "cell 0 1,grow");
		if (initSession != null) {
			selectedClasses.clear();
			selectedClasses.addAll(initSession.getSelectedClasses());
			this.currStudent = initSession.getCurrStudent();
		}
		frame.setTitle("MWHS Class chooser for " + currStudent.getName());
		lblStudent = new JLabel("User: " + currStudent.getAccName());
		panel.add(lblStudent);
		update();

	}

	protected void createNextYearDialog() {
		if (!hasSaved) {
			int n = showSaveDialog();
			if (n == 0) {
				exportSession();
				CCNextYearDialog dialog = new CCNextYearDialog(frame,
						selectedClasses, allClasses, new CCDataManager(),
						DATA_PATH);
				dialog.setVisible(true);
				dialog.setAutoRequestFocus(true);
				if (dialog.getNewClasses() != null) {
					selectedClasses.clear();
					for (CCClass c : dialog.getNewClasses()) {
						selectedClasses.add(c);
					}
					update();
				}
			}
			if (n != 2) {
				CCNextYearDialog dialog = new CCNextYearDialog(frame,
						selectedClasses, allClasses, new CCDataManager(),
						DATA_PATH);
				dialog.setVisible(true);
				dialog.setAutoRequestFocus(true);
				if (dialog.getNewClasses() != null) {
					selectedClasses.clear();
					for (CCClass c : dialog.getNewClasses()) {
						selectedClasses.add(c);
					}
					update();
				}
			}
		} else {
			CCNextYearDialog dialog = new CCNextYearDialog(frame,
					selectedClasses, allClasses, new CCDataManager(), DATA_PATH);
			dialog.setVisible(true);
			dialog.setAutoRequestFocus(true);
			if (dialog.getNewClasses() != null) {
				selectedClasses.clear();
				for (CCClass c : dialog.getNewClasses()) {
					selectedClasses.add(c);
				}
				update();
			}
		}

	}

	protected void changeUser() {
		if (!hasSaved) {
			int n = showSaveDialog();
			if (n == 0) {
				exportSession();
			}
			if (n != 2) {
				getStudentInfo();
				currStudent = new Student(name, advisor, idNumber,
						grades.toLowerCase());
				selectedClasses.clear();
				update();
			}
		} else {
			getStudentInfo();
			currStudent = new Student(name, advisor, idNumber,
					grades.toLowerCase());
			selectedClasses.clear();
			update();
		}

	}

	public int showSaveDialog() {
		Object[] options = { "Export", "Continue without exporting", "Cancel" };
		return JOptionPane.showOptionDialog(frame, "You have unsaved work!",
				"Export", JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE, null, options, options[2]);
	}

	protected void setStartingSession() {
		fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		int returnVal = fc.showOpenDialog(frame);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			File file = fc.getSelectedFile();
			initSession = new CCDataManager().readSession(file);
		}
	}

	protected void importSession() {
		if (!hasSaved) {
			int n = showSaveDialog();
			if (n == 0) {
				exportSession();
				fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
				int returnVal = fc.showOpenDialog(frame);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();
					CCSession session = new CCDataManager().readSession(file);
					selectedClasses.clear();
					selectedClasses.addAll(session.getSelectedClasses());
					this.currStudent = session.getCurrStudent();
					update();
				}
			}
			if (n != 2) {
				fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
				int returnVal = fc.showOpenDialog(frame);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();
					CCSession session = new CCDataManager().readSession(file);
					selectedClasses.clear();
					selectedClasses.addAll(session.getSelectedClasses());
					this.currStudent = session.getCurrStudent();
					update();
				}
			}
		} else {
			fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			int returnVal = fc.showOpenDialog(frame);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File file = fc.getSelectedFile();
				CCSession session = new CCDataManager().readSession(file);
				selectedClasses.clear();
				selectedClasses.addAll(session.getSelectedClasses());
				this.currStudent = session.getCurrStudent();
				update();
			}
		}

	}

	protected void exportSession() {
		fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		int returnVal = fc.showSaveDialog(frame);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			File file = fc.getSelectedFile();
			new CCDataManager().writeSession(new CCSession(selectedClasses,
					currStudent), file.getAbsolutePath());
		}
		hasSaved = true;
		String title = frame.getTitle();
		frame.setTitle(title.substring(0, title.length() - 1));
	}

	private void getStudentInfo() {
		name = JOptionPane.showInputDialog("First and Last name: ");
		if (name == null) {
			System.exit(0);
		}
		idNumber = JOptionPane.showInputDialog("Student ID number: ");
		if (idNumber == null) {
			System.exit(0);
		}
		advisor = JOptionPane.showInputDialog("Advisor: ");
		if (advisor == null) {
			System.exit(0);
		}
		Object[] choices = { "Freshman", "Sophomore", "Junior", "Senior" };
		grades = (String) JOptionPane.showInputDialog(frame, "Grade: ",
				"Enter grade", JOptionPane.PLAIN_MESSAGE, null, choices,
				"Freshman");
		if (grades == null) {
			System.exit(0);
		}
	}

	/**
	 * Remove a class from selected classes
	 * 
	 */
	protected void removeElement() {
		String row = (String) tableModel.getValueAt(table.getSelectedRow(), 0);
		int toRemove = Integer.parseInt(row.replaceAll("[^0-9]", ""));
		for (int i = selectedClasses.size() - 1; i >= 0; i--) {
			if (Integer.parseInt(selectedClasses.get(i).getCourseNumber()) == toRemove) {
				selectedClasses.remove(i);
				break;
			}
		}
		update();
	}

	protected void addElement(boolean byType) {
		CCDialog dialog = new CCDialog(frame, allClasses, translations, byType);
		dialog.setVisible(true);
		dialog.setAutoRequestFocus(true);
		if (dialog.getSelectedClass() != null) {
			selectedClasses.add((CCClass) dialog.getSelectedClass());
		}
		update();
	}

	private void update() {
		frame.setTitle("MWHS Class chooser for " + currStudent.getName());
		int rows = tableModel.getRowCount();
		for (int i = rows - 1; i >= 0; i--) {
			tableModel.removeRow(i);
		}
		int runningTotal = 0;
		for (CCClass c : selectedClasses) {
			tableModel.addRow(new Object[] { c.getCourseNumber(),
					c.getCourseName(), c.getCreditNumber() });
			runningTotal += c.getCreditNumber();
		}
		hasSaved = false;
		totalCredits.setText("Total credits: " + runningTotal);
		frame.setTitle("MWHS Class chooser for " + currStudent.getName());
		lblStudent.setText("User: " + currStudent.getAccName());
		frame.setTitle(frame.getTitle() + "*");
	}
}