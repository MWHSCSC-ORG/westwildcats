package org.djohnson.cc;

import java.util.*;

public class CCScheduler {
	
	private ArrayList<CCClass> allClasses;
	private ArrayList<CCClassSequence> allSeqs;
	
	public CCScheduler(ArrayList<CCClass> allClasses, ArrayList<CCClassSequence> allSeqs){
		this.allClasses = allClasses;
		this.allSeqs = allSeqs;
	}
	
	public CCScheduler(ArrayList<CCClass> allClasses) {
		this.allClasses = allClasses;
	}
	
	public void setClassSeqs(ArrayList<CCClassSequence> allSeqs){
		this.allSeqs = allSeqs;
	}
	
	public CCClass getNextInSequence(CCClass c) throws InvalidSequenceSearchException{
		for(CCClassSequence seq : allSeqs){
			if(seq.sequenceContainsClass(c)){
				try{
					return seq.getNextInSequence(c);
				}catch(InvalidSequenceSearchException e){
				}
			}
		}
		throw new InvalidSequenceSearchException();
	}
	
	public CCClass findClassById(String id){
		for(CCClass c : allClasses){
			if(c.getCourseNumber().equalsIgnoreCase(id)){
				return c;
			}
		}
		return null;
	}
	
	
}
