package org.djohnson.printing;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import org.djohnson.cc.CCClass;
import org.djohnson.cc.Student;

public class CCClassList implements Printable {

	ArrayList<CCClass> selectedClasses;
	private Student currStudent;

	public CCClassList(ArrayList<CCClass> selectedClasses, Student currStudent) {
		this.selectedClasses = selectedClasses;
		this.currStudent = currStudent;
	}

	@Override
	public int print(Graphics graphics, PageFormat pageFormat, int pageIndex)
			throws PrinterException {

		if (pageIndex > 0) {
			return NO_SUCH_PAGE;
		}

		Graphics2D g = (Graphics2D) graphics;
		g.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

		try {
			BufferedImage image = ImageIO.read(new File("classdata/Registration.png"));
			g.drawImage(image, 0, 0, null);
		} catch (MalformedURLException e) {
			
		} catch (IOException e) {
			
		}

		float yStudent = (float) 139;
		g.drawString(currStudent.getName(), 108, yStudent);
		g.drawString(currStudent.getAdvisor(), 369, yStudent);
		g.drawString(currStudent.getIdNumber(), 126, (float) 166);

		int totalCred = 0;
		float xNum = 36;
		float xName = 153;
		float xCred = 477;
		float yCred = (float) 210.5;
		for (CCClass c : selectedClasses) {
			g.drawString(c.getCourseNumber(), xNum, yCred);
			g.drawString(c.getCourseName(), xName, yCred);
			g.drawString(c.getCreditNumber() + "", xCred, yCred);
			yCred += 23;
			totalCred += c.getCreditNumber();
		}

		g.drawString(totalCred + "", xCred, (float) 585);

		return PAGE_EXISTS;
	}

}
